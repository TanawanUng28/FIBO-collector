FIBO collector
